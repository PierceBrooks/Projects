def number_of_nodes_objective(graph_pipeline):
    return graph_pipeline.graph.number_of_nodes()